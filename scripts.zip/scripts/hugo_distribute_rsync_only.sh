#!/bin/sh
#
# Purpose: Distribute Hugo Sprocket changes and restart the servers
# Author:  Andrew Roberts 2008-06-11
# Version: 0.2
#
SYNC_DIR="/tui/sprocket/sf/conf"
RSYNC_CMD="/opt/rsync/bin/rsync"
INIT_SCRPT="/etc/init.d/apache2_hugo_sprocket"
EXCL_FL="$HOME/sprocket_ctl/rsync_excludes.txt"
#
if [ ! -f "$HOME/servers/sprocket-web" ]
then
  echo "Error: Server file missing - $HOME/servers/sprocket-web"
  exit 1
fi
#
cd $SYNC_DIR
#
for SERV in `cat $HOME/servers/sprocket-web`
do
  echo $SERV
  $RSYNC_CMD -optlg --exclude-from=$EXCL_FL --rsh=/usr/bin/ssh --rsync-path="$RSYNC_CMD" --recursive --force --delete-after "$SYNC_DIR/" "$SERV:$SYNC_DIR"
done

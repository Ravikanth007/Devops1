#!/sbin/sh
LD_LIBRARY_PATH=/usr/sfw/lib:/opt/gcc-4.0.2-64bit/lib:${LD_LIBRARY_PATH}
export LD_LIBRARY_PATH
APACHE2_HOME=/opt/httpd-latest
SPROCKET_HOME=/tui/sprocket
THIS_HOST="HUGO-Sprocket"
CONF_DIR="$SPROCKET_HOME/sf/conf/"
. /etc/init.d/EnvApache.sh
CONF_FILE=$AppBaseDir/conf/httpd.conf
PIDFILE=$AppBaseDir/apachelogs/httpd.pid
#
$APACHE2_HOME/bin/httpd -t -f $CONF_FILE
